import React, { useState, useEffect } from 'react';
import { getDashboardData } from '../../admin/service/dashBoardService';

function OrderDetails() {

    const [orderData, setOrderData] = useState('');
    return (

    )
}
export default OrderDetails;